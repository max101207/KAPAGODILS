﻿using System;
using Microsoft.Maui.Controls;

namespace $safeprojectname$;

public partial class CatCart : ContentPage
{
    public CatCart()
    {
        InitializeComponent();

        // Bottom Navigation Button Handlers
        var chatTap = new TapGestureRecognizer();
        chatTap.Tapped += ChatButton_Clicked;
        ChatButton.GestureRecognizers.Add(chatTap);

        var homeTap = new TapGestureRecognizer();
        homeTap.Tapped += HomeButton_Clicked;
        HomeButton.GestureRecognizers.Add(homeTap);

        var profileTap = new TapGestureRecognizer();
        profileTap.Tapped += ProfileButton_Clicked;
        ProfileButton.GestureRecognizers.Add(profileTap);
    }

    // Cat Breed Frame Tap Handlers
    private void RagdollFrame_Tapped(object sender, EventArgs e) => DisplayAlert("Order-in mo na!<3", "Ragdoll Cat - Php 13,000", "OK");

    private void MaineCoonFrame_Tapped(object sender, EventArgs e)
    {
        DisplayAlert("Order-in mo na!<3", "Maine Coon Cat - Php 22,000", "OK");
    }

    private void SiberianFrame_Tapped(object sender, EventArgs e)
    {
        DisplayAlert("Order-in mo na!<3", "Siberian Cat - Php 27,000", "OK");
    }

    private void BombayFrame_Tapped(object sender, EventArgs e)
    {
        DisplayAlert("Order-in mo na!<3", "Bombay Cat - Php 13,000", "OK");
    }

    // sakit sa ulo neto ah
    private void ChatButton_Clicked(object sender, EventArgs e)
    {
        DisplayAlert("Chat", "Ano kailangan mo?", "OK");
    }

    private void HomeButton_Clicked(object sender, EventArgs e)
    {
        DisplayAlert("Home", "Bili ka muna, please", "OK");
    }

    private void ProfileButton_Clicked(object sender, EventArgs e)
    {
        DisplayAlert("Profile", "Lagay mo na address mo", "OK");
    }
}