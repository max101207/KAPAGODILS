﻿using Microsoft.Extensions.Logging;

namespace $safeprojectname$;

public static class MauiProgram
{
    public static MauiApp CreateMauiApp()
    {
        var builder = MauiApp.CreateBuilder();
        builder
            .UseMauiApp<App>()
            .ConfigureFonts(fonts =>
            {
                fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                fonts.AddFont("Roomach-Regular.ttf", "RoomachRegular"); // HIirap hanapin ng font na to kainis
            });

#if DEBUG
        builder.Logging.AddDebug();
#endif

        return builder.Build();
    }
}