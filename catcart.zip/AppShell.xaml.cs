﻿namespace $safeprojectname$;

public partial class AppShell : Shell
{
    public AppShell()
    {
        InitializeComponent();
        Routing.RegisterRoute(nameof(CatCart), typeof(CatCart));
        Routing.RegisterRoute(nameof(LoginPage), typeof(LoginPage));
    }
}